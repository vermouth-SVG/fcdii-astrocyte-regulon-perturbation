# Additional file 2. Supplementary Tables ST01-ST09

Single-nucleus transcriptomic reanalysis prioritizes NFE2L2 and THRB regulatory programs in focal cortical dysplasia type II astrocytes.

All supplementary tables are supplied in the accompanying XLSX workbook.

Supplementary Table | Title | Legend
ST01 | Dataset roles | Datasets used in the study and the analysis role of each.
ST02 | Candidate transcription-factor shortlist | The seven prioritized transcription factors with their axis, literature evidence class, screening-scale expression statistic R, regulon activity difference, regulon FDR and higher-group detection.
ST03 | Integrated transcription-factor prioritization | Prioritization metrics for the seven candidates, combining regulon and expression evidence with CellOracle mean shift, network-edge sensitivity, threshold retention and donor concordance.
ST04 | Full differential regulon statistics | Differential statistics for all 105 motif-supported regulons. The mean AUCell difference is lesion minus internal-control; the direction is sign-based and the FDR reports statistical support.
ST05 | CellOracle in silico perturbation metrics | CellOracle simulated perturbation metrics for the seven candidates: mean shift, net shift and the within-donor lesion-minus-control net-shift difference.
ST06 | Expression-scale, donor, threshold and network sensitivity | Expression-scale (R versus L), donor pseudobulk, threshold-retention and network-edge sensitivity metrics for the seven candidates.
ST07 | Supportive external expression analysis | Expression-level support for the seven prioritized candidates in GSE140393 (temporal lobe epilepsy) and GSE190452 (temporal lobe epilepsy versus non-epilepsy control). Support score and rank were retained from the archived curation for the three candidates with archived external expression support (NFE2L2, THRB and SOX2); for the remaining four candidates the seven-candidate support score recomputed in the re-run is reported. Group_log2FC, the cluster support fractions and detection in the higher group come from the seven-candidate re-run of GSE190452, and the per-sample detection fractions from the seven-candidate re-run of GSE140393; these are the values plotted in Figure S4.
ST08 | Functional enrichment of candidate target sets | GO and KEGG enrichment breadth for each candidate's regulon targets and direction-consistent intersection.
ST09 | Drug-signature enrichment | Drug-signature enrichment of the NFE2L2 and THRB candidate-derived query sets against DSigDB, with the mTOR-axis and supportive lead layers and blood-brain barrier annotation.
